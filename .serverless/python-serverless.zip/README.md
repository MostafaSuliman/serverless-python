# serverless-python

serverless app with SNS SQS , Lambda function
